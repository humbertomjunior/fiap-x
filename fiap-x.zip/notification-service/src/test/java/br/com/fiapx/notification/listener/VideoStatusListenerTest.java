package br.com.fiapx.notification.listener;

import br.com.fiapx.common.event.VideoStatusEvent;
import br.com.fiapx.notification.service.NotificationService;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class VideoStatusListenerTest {

    @Test
    void shouldForwardStatusEventToNotificationService() {
        NotificationService notificationService = mock(NotificationService.class);
        VideoStatusListener listener = new VideoStatusListener(notificationService);
        VideoStatusEvent event = new VideoStatusEvent(
                UUID.randomUUID(),
                UUID.randomUUID(),
                "user@fiapx.com",
                "FINISHED",
                "/tmp/video.zip",
                null,
                LocalDateTime.now()
        );

        listener.handle(event);

        verify(notificationService).process(event);
    }
}
